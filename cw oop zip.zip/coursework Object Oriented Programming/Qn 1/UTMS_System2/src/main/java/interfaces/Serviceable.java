package interfaces;

public interface Serviceable {
    void performMaintenance();
    String getLastServiceDate();
}